<?php
header('HTTP/1.1 403 Forbidden');
echo 'Directory listing is not allowed.';
exit; 